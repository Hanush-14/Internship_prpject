import tkinter as tk
from tkinter import messagebox
from main_gui import HospitalGUI

class LoginPage:

    def __init__(self, root):
        self.root = root
        self.root.title("Login - Hospital System")
        self.root.geometry("400x300")
        self.root.resizable(False, False)

        self.username = tk.StringVar()
        self.password = tk.StringVar()

        self.build_ui()

    def build_ui(self):

        tk.Label(self.root, text="Hospital Login",
                 font=("Arial", 20, "bold")).pack(pady=20)

        frame = tk.Frame(self.root)
        frame.pack(pady=10)

        tk.Label(frame, text="Username").grid(row=0, column=0, pady=10)
        tk.Entry(frame, textvariable=self.username).grid(row=0, column=1)

        tk.Label(frame, text="Password").grid(row=1, column=0, pady=10)
        tk.Entry(frame, textvariable=self.password, show="*").grid(row=1, column=1)

        tk.Button(self.root, text="Login",
                  bg="green", fg="white",
                  command=self.check_login).pack(pady=20)

    def check_login(self):

        user = self.username.get()
        pwd = self.password.get()

        # 🔐 Simple hardcoded login (you can connect DB later)
        if user == "admin" and pwd == "1234":
            messagebox.showinfo("Success", "Login Successful")

            self.root.destroy()  # close login window

            main_root = tk.Tk()
            app = HospitalGUI(main_root)
            main_root.mainloop()

        else:
            messagebox.showerror("Error", "Invalid Username or Password")


# RUN
if __name__ == "__main__":
    root = tk.Tk()
    app = LoginPage(root)
    root.mainloop()