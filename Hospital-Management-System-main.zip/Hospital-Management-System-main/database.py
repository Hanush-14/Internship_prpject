import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Hanu14$2003",   # change this
    database="hospital"
)

cursor = conn.cursor()