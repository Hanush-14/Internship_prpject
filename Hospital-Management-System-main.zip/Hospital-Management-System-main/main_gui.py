import tkinter as tk
from tkinter import *
from tkinter import ttk, messagebox
from database import cursor, conn


class HospitalGUI:

    def __init__(self, root):
        self.root = root
        self.root.title("Hospital Management System")
        self.root.state("zoomed")
        self.create_gui()

    # ---------------- GUI ----------------
    def create_gui(self):

        Label(self.root, text="Hospital Management System",
              fg="white", bg="#2c3e50",
              font=("Arial", 28, "bold")).pack(fill="x")

        Dataframe = Frame(self.root, bg="#ecf0f1")
        Dataframe.place(x=0, y=60, relwidth=1, height=350)

        self.left = LabelFrame(Dataframe, text="Information Panel", bg="#ecf0f1")
        self.left.place(relwidth=0.7, relheight=1)

        # BILL PANEL
        right = LabelFrame(Dataframe, text="Bill Panel", bg="#ecf0f1")
        right.place(relx=0.7, rely=0, relwidth=0.3, relheight=1)
        right.pack_propagate(False)

        self.bill_text = Text(right, font=("Consolas", 11))
        self.bill_text.pack(expand=True, fill=BOTH)

        btn_frame = Frame(self.root, bg="#bdc3c7")
        btn_frame.place(x=0, y=420, relwidth=1, height=60)

        self.bottom = Frame(self.root, bg="#ecf0f1")
        self.bottom.place(x=0, y=490, relwidth=1, height=250)

        self.notebook = ttk.Notebook(self.bottom)
        self.notebook.pack(expand=True, fill=BOTH)

        self.patient_tab = Frame(self.notebook)
        self.doctor_tab = Frame(self.notebook)

        self.notebook.add(self.patient_tab, text="Patients")
        self.notebook.add(self.doctor_tab, text="Doctors")

        self.create_patient_table()
        self.create_doctor_table()
        self.create_patient_form()

        btn = {"bg": "#2980b9", "fg": "white", "width": 15}

        Button(btn_frame, text="Add Patient", command=self.create_patient_form, **btn).grid(row=0, column=0)
        Button(btn_frame, text="Add Doctor", command=self.create_doctor_form, **btn).grid(row=0, column=1)
        Button(btn_frame, text="Assign Doctor", command=self.create_assign_form, **btn).grid(row=0, column=2)
        Button(btn_frame, text="Delete Patient", command=self.create_delete_form, **btn).grid(row=0, column=3)
        Button(btn_frame, text="Show Patients", command=self.show_patients, **btn).grid(row=0, column=4)
        Button(btn_frame, text="Show Doctors", command=self.show_doctors, **btn).grid(row=0, column=5)
        Button(btn_frame, text="Exit", command=self.root.quit, bg="red", fg="white").grid(row=0, column=6)

    # ---------------- TABLES ----------------
    def create_patient_table(self):
        self.patient_tree = ttk.Treeview(
            self.patient_tab,
            columns=("ID", "Name", "Age", "Gender", "Disease", "Doctor"),
            show="headings"
        )

        for col in self.patient_tree["columns"]:
            self.patient_tree.heading(col, text=col)

        self.patient_tree.pack(expand=True, fill=BOTH)

        # ⭐ CLICK EVENT FOR BILL POPUP
        self.patient_tree.bind("<<TreeviewSelect>>", self.on_patient_select)

    def create_doctor_table(self):
        self.doctor_tree = ttk.Treeview(
            self.doctor_tab,
            columns=("ID", "Name", "Age", "Gender", "Specialization"),
            show="headings"
        )

        for col in self.doctor_tree["columns"]:
            self.doctor_tree.heading(col, text=col)

        self.doctor_tree.pack(expand=True, fill=BOTH)

    # ---------------- FORMS ----------------
    def clear(self):
        for w in self.left.winfo_children():
            w.destroy()

    def create_patient_form(self):
        self.clear()

        self.name = StringVar()
        self.age = StringVar()
        self.gender = StringVar()
        self.disease = StringVar()

        Label(self.left, text="Name").grid(row=0, column=0)
        Entry(self.left, textvariable=self.name).grid(row=0, column=1)

        Label(self.left, text="Age").grid(row=1, column=0)
        Entry(self.left, textvariable=self.age).grid(row=1, column=1)

        Label(self.left, text="Gender").grid(row=2, column=0)
        Entry(self.left, textvariable=self.gender).grid(row=2, column=1)

        Label(self.left, text="Disease").grid(row=3, column=0)
        Entry(self.left, textvariable=self.disease).grid(row=3, column=1)

        Button(self.left, text="Submit", command=self.add_patient).grid(row=4, columnspan=2)

    def create_doctor_form(self):
        self.clear()

        self.did = StringVar()
        self.dname = StringVar()
        self.dage = StringVar()
        self.dgender = StringVar()
        self.spec = StringVar()

        Label(self.left, text="Doctor ID").grid(row=0)
        Entry(self.left, textvariable=self.did).grid(row=0, column=1)

        Label(self.left, text="Name").grid(row=1)
        Entry(self.left, textvariable=self.dname).grid(row=1, column=1)

        Label(self.left, text="Age").grid(row=2)
        Entry(self.left, textvariable=self.dage).grid(row=2, column=1)

        Label(self.left, text="Gender").grid(row=3)
        Entry(self.left, textvariable=self.dgender).grid(row=3, column=1)

        Label(self.left, text="Specialization").grid(row=4)
        Entry(self.left, textvariable=self.spec).grid(row=4, column=1)

        Button(self.left, text="Submit", command=self.add_doctor).grid(row=5, columnspan=2)

    def create_assign_form(self):
        self.clear()

        self.pid = StringVar()
        self.did_assign = StringVar()

        Label(self.left, text="Patient ID").grid(row=0)
        Entry(self.left, textvariable=self.pid).grid(row=0, column=1)

        Label(self.left, text="Doctor ID").grid(row=1)
        Entry(self.left, textvariable=self.did_assign).grid(row=1, column=1)

        Button(self.left, text="Assign", command=self.assign_doctor).grid(row=2, columnspan=2)

    def create_delete_form(self):
        self.clear()

        self.del_id = StringVar()

        Label(self.left, text="Patient ID").grid(row=0)
        Entry(self.left, textvariable=self.del_id).grid(row=0, column=1)

        Button(self.left, text="Delete", command=self.delete_patient).grid(row=1, columnspan=2)

    # ---------------- DATABASE ----------------
    def add_patient(self):
        cursor.execute(
            "INSERT INTO patients(name,age,gender,disease) VALUES(%s,%s,%s,%s)",
            (self.name.get(), self.age.get(), self.gender.get(), self.disease.get())
        )
        conn.commit()
        messagebox.showinfo("Success", "Patient Added")

    def add_doctor(self):
        cursor.execute(
            "INSERT INTO doctors VALUES(%s,%s,%s,%s,%s)",
            (self.did.get(), self.dname.get(), self.dage.get(),
             self.dgender.get(), self.spec.get())
        )
        conn.commit()
        messagebox.showinfo("Success", "Doctor Added")

    def assign_doctor(self):
        cursor.execute(
            "UPDATE patients SET assigned_doctor_id=%s WHERE patient_id=%s",
            (self.did_assign.get(), self.pid.get())
        )
        conn.commit()
        messagebox.showinfo("Success", "Doctor Assigned")

    def delete_patient(self):
        cursor.execute("DELETE FROM patients WHERE patient_id=%s", (self.del_id.get(),))
        conn.commit()
        messagebox.showinfo("Deleted", "Patient Removed")

    def show_patients(self):
        self.patient_tree.delete(*self.patient_tree.get_children())
        cursor.execute("SELECT * FROM patients")
        for row in cursor.fetchall():
            self.patient_tree.insert("", END, values=row)

    def show_doctors(self):
        self.doctor_tree.delete(*self.doctor_tree.get_children())
        cursor.execute("SELECT * FROM doctors")
        for row in cursor.fetchall():
            self.doctor_tree.insert("", END, values=row)

    # ---------------- BILL POPUP ----------------
    def on_patient_select(self, event):
        selected = self.patient_tree.focus()
        data = self.patient_tree.item(selected, "values")

        if not data:
            return

        pid = data[0]

        popup = Toplevel(self.root)
        popup.title("Generate Bill")
        popup.geometry("300x200")

        days = StringVar()
        rate = StringVar()

        Label(popup, text=f"Patient ID: {pid}").pack(pady=5)

        Label(popup, text="Days").pack()
        Entry(popup, textvariable=days).pack()

        Label(popup, text="Rate").pack()
        Entry(popup, textvariable=rate).pack()

        def generate():
            try:
                d = int(days.get())
                r = int(rate.get())

                cursor.execute("SELECT * FROM patients WHERE patient_id=%s", (pid,))
                p = cursor.fetchone()

                total = d * r

                bill = f"""
----- BILL -----
Patient ID : {p[0]}
Name       : {p[1]}
Disease    : {p[4]}
Days       : {d}
Rate       : {r}
TOTAL      : {total}
"""

                self.bill_text.delete("1.0", END)
                self.bill_text.insert(END, bill)

                popup.destroy()

            except Exception as e:
                messagebox.showerror("Error", str(e))

        Button(popup, text="Generate Bill", bg="green", fg="white",
               command=generate).pack(pady=10)


# RUN
if __name__ == "__main__":
    root = tk.Tk()
    app = HospitalGUI(root)
    root.mainloop()